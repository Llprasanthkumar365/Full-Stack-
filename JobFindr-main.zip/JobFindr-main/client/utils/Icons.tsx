export const bookmarkEmpty = <i className="fa-regular fa-bookmark"></i>;
export const bookmark = <i className="fa-solid fa-bookmark"></i>;
export const location = <i className="fa-solid fa-location-dot"></i>;
export const grip = <i className="fa-solid fa-grip"></i>;
export const list = <i className="fa-solid fa-list-ul"></i>;
export const table = <i className="fa-solid fa-table-columns"></i>;
